import Foundation

@objc public class CapacitorFacebookAd: NSObject {
    @objc public func echo(_ value: String) -> String {
        return value
    }
}
