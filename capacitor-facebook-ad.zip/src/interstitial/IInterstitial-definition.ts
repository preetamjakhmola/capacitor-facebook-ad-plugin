export interface InterstitialDefinitions{
    
}