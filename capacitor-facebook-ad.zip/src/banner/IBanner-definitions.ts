export interface IBannerDefinitions {


}