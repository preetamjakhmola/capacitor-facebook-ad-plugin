export interface AdLoadInfo {
  adPlacementId: string
}