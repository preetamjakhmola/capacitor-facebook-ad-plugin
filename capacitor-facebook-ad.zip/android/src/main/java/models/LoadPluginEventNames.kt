package models

interface LoadPluginEventNames {
    val Showed: String
    val FailedToShow: String
    val Dismissed: String
}